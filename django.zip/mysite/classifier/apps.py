from django.apps import AppConfig


class ClassifierConfig(AppConfig):
    name = 'classifier'
