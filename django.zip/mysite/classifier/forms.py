from django import forms

class TxtForm(forms.Form):
    text = forms.CharField(label='text', widget = forms.Textarea)